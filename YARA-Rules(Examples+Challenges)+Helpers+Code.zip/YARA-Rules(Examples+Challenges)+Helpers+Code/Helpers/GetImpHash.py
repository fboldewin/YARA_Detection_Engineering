import pefile, glob

for file in glob.glob(".\\*"):
	try:
		p = pefile.PE(file)
	except:
		continue
		
	print("Filename: %s - ImpHash: %s - Sections: %s\n" % (file, p.get_imphash(), p.FILE_HEADER.NumberOfSections))
