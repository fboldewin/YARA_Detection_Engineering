import yara, struct, pefile, json

def ksa(key):
	keylength = len(key)
	S = list(range(256))
	j = 0
	for i in range(256):
		k = ord(key[i % keylength])
		j = (j + S[i] + k) % 126
		S[i], S[j] = S[j], S[i]
	return S

def decrypt_config(key):
	S = ksa(key); i = 0; j = 0
	decrypted_config = b''
	
	for i in range (0,Bloblen):
		char = chr(data_section[i])
		i = (i + 1) % 126
		j = (j + S[i]) % 126
		S[i], S[j] = S[j], S[i]
		k = S[(S[i] + S[j]) % 126]
		decrypted_config += bytes(chr(ord(char) ^ k).encode())
	return (decrypted_config)

rule_source = """
rule RagnarokConfigDecryptionRoutine {
	strings:
		$key = { 6A 00 50 E8 ?? ?? ?? ?? 8D 85 FC FD FF FF 68 ?? ?? ?? ?? 50 }
		$bloblen = { 30 87 ?? ?? ?? ?? 47 8B 45 FC 81 FF }
	condition:
		all of them
} """

pe = pefile.PE(".\\Samples\\01e7ba4b23b94269f16bef68f685950b8e036ae0f79aad335123de53e3e43057")
code_section = pe.get_data(pe.sections[0].VirtualAddress,pe.sections[0].Misc_VirtualSize)
rdata_section = pe.get_data(pe.sections[1].VirtualAddress,pe.sections[1].Misc_VirtualSize)
data_section = pe.get_data(pe.sections[2].VirtualAddress,pe.sections[2].Misc_VirtualSize)
va = pe.sections[1].VirtualAddress

rules = yara.compile(source=rule_source)
matches = rules.match(data=code_section)
if matches:
	for match in matches:
		for string in match.strings:
			if string.identifier == '$bloblen':
				OffBlobLen = string.instances[0].offset
				Bloblen = struct.unpack('i', code_section[OffBlobLen+12:OffBlobLen+12+4])[0]
			elif string.identifier == '$key':
				Offset2Key = string.instances[0].offset
				addr = struct.unpack('i', code_section[Offset2Key+15:Offset2Key+15+4])[0]-pe.OPTIONAL_HEADER.ImageBase-va
				key = ''
				while rdata_section[addr] != 0x00:
					key += chr(rdata_section[addr])
					addr += 1
		print(json.dumps(json.loads(decrypt_config(key)), indent=2))
